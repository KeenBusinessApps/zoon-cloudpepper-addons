{
    'name': 'Insabhi Barcode Storage',
    'author': 'Insabhi',
    'depends': ['base', 'web', 'stock', 'barcodes', 'product_barcode'],
    'data': [
            'views/main_menu.xml',
            'views/location_add_section.xml',
            'views/warehouse_page.xml',
    ],
    'assets': {
            'web.assets_backend': [
                'insabhi_barcode/static/src/js/popup.js',
        ]
    }

}