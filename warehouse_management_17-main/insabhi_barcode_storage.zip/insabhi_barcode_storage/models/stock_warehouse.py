from odoo import models, fields

class StockLocation(models.Model):
    _inherit = 'stock.location'

    lot_stock_warehouse_id = fields.Many2one(
        'stock.warehouse', string='Warehouse'
    )


class StockWarehouse(models.Model):
    _inherit = 'stock.warehouse'

    lot_stock_ids = fields.One2many(
        'stock.location', 'lot_stock_warehouse_id',
        string='Stock Locations',
        domain = "[('usage', '=', 'internal'), ('company_id', '=', company_id)]",
    )
